﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hamaraBasket
{
    public class MovieTickets : Item
    {
        
        public MovieTickets(string name, int sellIn, int quality) : base(name, sellIn, quality) { }

        public override IItem Update(IItem item)
        {
            return item.SellIn > 1 ? UpdateMovieTicketsInfo(item as MovieTickets) : UpdateMovieTicketsQualityToZero(item as MovieTickets);
        }

        private MovieTickets UpdateMovieTicketsInfo(MovieTickets item)
        {
            item.Quality = item.Quality + 2;
            item.SellIn = item.SellIn - 1;
            return item;
        }

        private MovieTickets UpdateMovieTicketsQualityToZero(MovieTickets item)
        {
            item.SellIn = item.SellIn - 1;
            item.Quality = 0;
            return item;
        }
    }
}
