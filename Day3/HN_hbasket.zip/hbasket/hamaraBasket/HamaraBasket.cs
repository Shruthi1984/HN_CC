﻿using System.Collections.Generic;
using System;

namespace hamaraBasket
{
    public class HamaraBasket
    {
        IList<Item> Items;

        public HamaraBasket(IList<Item> Items)
        {
            this.Items = Items;
        }

        public void UpdateQuality()
        {
            foreach (var item in Items)
            {
                item.Update(item);
            }
        }
    }
}




