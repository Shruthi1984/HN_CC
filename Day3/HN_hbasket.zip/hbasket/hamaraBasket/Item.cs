﻿using System.Data;


namespace hamaraBasket
{
    public class Item : IItem
    {
        public Item( string name, int sellIn, int quality)
        {
            Name = name;
            SellIn = sellIn;
            Quality = quality;
        }
       
        public string Name { get; set; }
        public int SellIn { get; set; }
        public int Quality { get; set; }

        public override string ToString()
        {
            return this.Name + ", " + this.SellIn + ", " + this.Quality;
        }

        public virtual IItem Update(IItem item)
        {
            item.Quality = item.Quality - 1;
            item.SellIn = item.SellIn - 1;
            return item;
        }
        
    }
}
