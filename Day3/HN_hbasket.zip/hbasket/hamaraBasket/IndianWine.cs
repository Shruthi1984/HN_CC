﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hamaraBasket
{
    public class IndianWine : Item
    {
        public IndianWine(string name, int sellIn, int quality):base(name, sellIn, quality) { }
        public override IItem Update(IItem item)
        {
            item.Quality = item.Quality + 2;
            item.SellIn = item.SellIn - 1;
            return item;
        }
    }
}
