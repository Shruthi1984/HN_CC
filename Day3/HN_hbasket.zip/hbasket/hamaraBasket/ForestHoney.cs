﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hamaraBasket
{
    public class ForestHoney : Item
    {
        public ForestHoney(string name, int sellIn, int quality) : base(name, sellIn, quality) { }

        public override IItem Update(IItem item)
        {
            return item;
        }
    }
}
