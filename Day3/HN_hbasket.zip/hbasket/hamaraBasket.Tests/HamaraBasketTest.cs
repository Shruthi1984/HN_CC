﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System.Collections.Generic;

using hamaraBasket.Tests;


namespace hamaraBasket
{
    [TestFixture]
    public class HamaraBasketTest
    {
        private DomainFactory factory;

        [SetUp]
        public void SetUp()
        {
            factory = new DomainFactory();
        }

        [TestCase("Standard Item", 10, 20)]
        public void ShouldReduceSellInValueByOneEOD(string itemName, int sellIn, int quality)
        {
            var items = factory.PrepareItems(itemName, sellIn, quality);
            factory.CallUpdateQuality(items);
            Assert.That(items[0].SellIn, Is.EqualTo(9));
            Assert.That(items[0].Quality, Is.EqualTo(19));
        }

        [TestCase("Indian Wine", 10, 20)]
        public void ShouldIncreaseQualityValueByTwoEOD(string itemName, int sellIn, int quality)
        {
            var items = factory.PrepareItems(itemName, sellIn, quality);
            factory.CallUpdateQuality(items);

            Assert.That(items[0].Quality, Is.EqualTo(22));
            Assert.That(items[0].SellIn, Is.EqualTo(9));
        }

        [TestCase("Movie Tickets", 10, 20)]
        public void UpdateQuality_MovieTickets_IncreasesQuality(string itemName, int sellIn, int quality)
        {
            var items = factory.PrepareItems(itemName, sellIn, quality);
            factory.CallUpdateQuality(items);

            Assert.AreEqual(9, items[0].SellIn);
            Assert.AreEqual(22, items[0].Quality);
        }

        [TestCase("Forest Honey", 10, 20)]
        public void UpdateQuality_ForestHoney_DoesNotChange(string itemName, int sellIn, int quality)
        {
            var items = factory.PrepareItems(itemName, sellIn, quality);
            factory.CallUpdateQuality(items);

            Assert.AreEqual(10, items[0].SellIn);
            Assert.AreEqual(20, items[0].Quality);
        }

        [TestCase("Movie Tickets", 0, 20)]
        public void UpdateQuality_MovieTickets_QualityDropsToZeroAfterSellIn(string itemName, int sellIn, int quality)
        {
            var items = factory.PrepareItems("Movie Tickets", sellIn, quality);
            factory.CallUpdateQuality(items);

            Assert.AreEqual(-1, items[0].SellIn);
            Assert.AreEqual(0, items[0].Quality);
        }
    }
}
