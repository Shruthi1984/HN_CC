﻿using NUnit.Framework.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hamaraBasket.Tests
{
    public class DomainFactory
    {
        public IList<Item> PrepareItems(string name, int sellIn, int quality)
        {
            Item item = null;
            var items = new List<Item>();

            switch (name)
                {
                    case "Movie Tickets":
                        item = new MovieTickets(name, sellIn, quality);
                        break;
                    case "Indian Wine":
                        item = new IndianWine(name, sellIn, quality);
                    break;
                    case "Forest Honey":
                        item = new ForestHoney(name, sellIn, quality);
                    break;
                    default:
                        item = new Item(name, sellIn, quality);
                    break;
                }
            items.Add(item);
            return items;
        }

        public void CallUpdateQuality(IList<Item> items)
        {
            HamaraBasket app = new HamaraBasket(items);
            app.UpdateQuality();
        }
    }
}
